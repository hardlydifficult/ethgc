self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "896ab55bddb7a4712db2",
    "url": "/css/app.3f9830a0.css"
  },
  {
    "revision": "48e8b7211d55a1fbc3ae",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "5e5ea42306f94bc6c27d",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "39efd9920e665993a791c711dcbf246f",
    "url": "/index.html"
  },
  {
    "revision": "896ab55bddb7a4712db2",
    "url": "/js/app.799e60b5.js"
  },
  {
    "revision": "98e446af1ee01d3bd3bc",
    "url": "/js/chunk-2d0c0895.0221a1d4.js"
  },
  {
    "revision": "8dadfb0d71a4478c2782",
    "url": "/js/chunk-2d21ef2c.49b98496.js"
  },
  {
    "revision": "5864ddc9780fa52148f0",
    "url": "/js/chunk-2d22d3f5.6ab05451.js"
  },
  {
    "revision": "48e8b7211d55a1fbc3ae",
    "url": "/js/chunk-83caf4ba.d4230837.js"
  },
  {
    "revision": "5e5ea42306f94bc6c27d",
    "url": "/js/chunk-ad949e22.2e06e177.js"
  },
  {
    "revision": "f3558d2ed950d250d170",
    "url": "/js/chunk-vendors.49341c1e.js"
  },
  {
    "revision": "d2aef1fbeed97f45c27480d4d947516b",
    "url": "/js/chunk-vendors.49341c1e.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);