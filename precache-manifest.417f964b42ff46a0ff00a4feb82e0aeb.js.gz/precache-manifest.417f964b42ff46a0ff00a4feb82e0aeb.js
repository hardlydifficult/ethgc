self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "08442629728ed23d81e1",
    "url": "/css/app.3f9830a0.css"
  },
  {
    "revision": "8442068967deb75c1add",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "27f1e9e9777314e8af00",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "e22ef3a1fdfa15aaa5324ad9ff53d1e7",
    "url": "/index.html"
  },
  {
    "revision": "08442629728ed23d81e1",
    "url": "/js/app.5db9060c.js"
  },
  {
    "revision": "4b7b33971f37593acd76",
    "url": "/js/chunk-2d0c0895.f93a71c9.js"
  },
  {
    "revision": "c5be58cce27f3a05c045",
    "url": "/js/chunk-2d21ef2c.75d31284.js"
  },
  {
    "revision": "6823a26ca3020fd62ea2",
    "url": "/js/chunk-2d22d3f5.d736153f.js"
  },
  {
    "revision": "8442068967deb75c1add",
    "url": "/js/chunk-83caf4ba.c41313dd.js"
  },
  {
    "revision": "27f1e9e9777314e8af00",
    "url": "/js/chunk-ad949e22.c3a60c6b.js"
  },
  {
    "revision": "10313f2ad736aacfc4d0",
    "url": "/js/chunk-vendors.7a029bc7.js"
  },
  {
    "revision": "52381c393eaefa9d3dcdb4fbfc655fb0",
    "url": "/js/chunk-vendors.7a029bc7.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);