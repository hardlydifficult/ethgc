self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cfb80cf8c5a307a1d3b2",
    "url": "/css/app.3f9830a0.css"
  },
  {
    "revision": "82ae45e6779d2786fe1a",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "e65b75dbaf449e97869a",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "cf20425b09a5569e1c82d535f0c6971d",
    "url": "/index.html"
  },
  {
    "revision": "cfb80cf8c5a307a1d3b2",
    "url": "/js/app.56dd30a4.js"
  },
  {
    "revision": "7d1b2ec22748981ada0c",
    "url": "/js/chunk-2d0c0895.55fddb57.js"
  },
  {
    "revision": "0acd5fdade9f21013840",
    "url": "/js/chunk-2d21ef2c.73140b3d.js"
  },
  {
    "revision": "e1d12eecce90d3e76544",
    "url": "/js/chunk-2d22d3f5.78c34892.js"
  },
  {
    "revision": "82ae45e6779d2786fe1a",
    "url": "/js/chunk-83caf4ba.0e8dc8f7.js"
  },
  {
    "revision": "e65b75dbaf449e97869a",
    "url": "/js/chunk-ad949e22.7e84dd2e.js"
  },
  {
    "revision": "7bbb2d534adade5a8d6b",
    "url": "/js/chunk-vendors.a42235d7.js"
  },
  {
    "revision": "135526132885cfaae76757a12c8e7fd9",
    "url": "/js/chunk-vendors.a42235d7.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);