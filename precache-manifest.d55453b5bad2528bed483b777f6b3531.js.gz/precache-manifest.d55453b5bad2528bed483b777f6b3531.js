self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b2dba16699cb7a8060e0",
    "url": "/css/app.3f9830a0.css"
  },
  {
    "revision": "8495beae0ed33cdc0574",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "c512d878b32244fb8004",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "bd4b6162bb252133ab7abf29d7434c76",
    "url": "/index.html"
  },
  {
    "revision": "b2dba16699cb7a8060e0",
    "url": "/js/app.886531a8.js"
  },
  {
    "revision": "c6d6a154bc04900a5583",
    "url": "/js/chunk-2d0c0895.0faea5bc.js"
  },
  {
    "revision": "2362e52ce8c609837520",
    "url": "/js/chunk-2d21ef2c.bf101d5b.js"
  },
  {
    "revision": "fbb09cab4ffc7b921168",
    "url": "/js/chunk-2d22d3f5.4e1385cb.js"
  },
  {
    "revision": "8495beae0ed33cdc0574",
    "url": "/js/chunk-83caf4ba.ffdd8c88.js"
  },
  {
    "revision": "c512d878b32244fb8004",
    "url": "/js/chunk-ad949e22.fcf19983.js"
  },
  {
    "revision": "7bbb2d534adade5a8d6b",
    "url": "/js/chunk-vendors.a42235d7.js"
  },
  {
    "revision": "135526132885cfaae76757a12c8e7fd9",
    "url": "/js/chunk-vendors.a42235d7.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);