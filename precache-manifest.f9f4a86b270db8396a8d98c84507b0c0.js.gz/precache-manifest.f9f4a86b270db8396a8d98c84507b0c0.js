self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "96e8c3b7d44893b3f062",
    "url": "/css/app.56ff0a86.css"
  },
  {
    "revision": "a0896dddc17bbf823ae8",
    "url": "/css/chunk-83caf4ba.3f95806c.css"
  },
  {
    "revision": "bc29904a4b9f88bf2a31",
    "url": "/css/chunk-ad949e22.68276357.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "b14f0addc57738d202203ef52002672d",
    "url": "/index.html"
  },
  {
    "revision": "96e8c3b7d44893b3f062",
    "url": "/js/app.01710d6f.js"
  },
  {
    "revision": "63e584eae498a3bb0a73",
    "url": "/js/chunk-2d0c0895.2022bafe.js"
  },
  {
    "revision": "dfe1ef23e6cb8107146e",
    "url": "/js/chunk-2d21ef2c.e4f81cce.js"
  },
  {
    "revision": "aa0d2ee8dca865ed2a85",
    "url": "/js/chunk-2d22d3f5.8ba4596a.js"
  },
  {
    "revision": "a0896dddc17bbf823ae8",
    "url": "/js/chunk-83caf4ba.d31c26da.js"
  },
  {
    "revision": "bc29904a4b9f88bf2a31",
    "url": "/js/chunk-ad949e22.ddb1a0b0.js"
  },
  {
    "revision": "7283447763fce4922d8c",
    "url": "/js/chunk-vendors.390e9a92.js"
  },
  {
    "revision": "07f5e22785feaadf7d3c8852f080bcb9",
    "url": "/js/chunk-vendors.390e9a92.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);