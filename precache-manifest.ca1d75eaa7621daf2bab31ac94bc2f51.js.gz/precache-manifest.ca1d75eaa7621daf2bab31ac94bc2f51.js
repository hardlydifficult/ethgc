self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dcf5c65a3c4f3e536d3a",
    "url": "/css/app.b6536d3e.css"
  },
  {
    "revision": "6e7796b7376b6fc5070b",
    "url": "/css/chunk-83caf4ba.3f95806c.css"
  },
  {
    "revision": "735de989745c5603386a",
    "url": "/css/chunk-ad949e22.68276357.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "e25f1f3b86900a9653f3c41f17f1da98",
    "url": "/index.html"
  },
  {
    "revision": "dcf5c65a3c4f3e536d3a",
    "url": "/js/app.fd207648.js"
  },
  {
    "revision": "dec10fac744f2aac9083",
    "url": "/js/chunk-2d0c0895.e5c15a16.js"
  },
  {
    "revision": "ee800277b31be5071c2b",
    "url": "/js/chunk-2d21ef2c.8bd58e8b.js"
  },
  {
    "revision": "053f77b7fa96995c62f2",
    "url": "/js/chunk-2d22d3f5.5fb05e5b.js"
  },
  {
    "revision": "6e7796b7376b6fc5070b",
    "url": "/js/chunk-83caf4ba.965c24ac.js"
  },
  {
    "revision": "735de989745c5603386a",
    "url": "/js/chunk-ad949e22.77b0b4f7.js"
  },
  {
    "revision": "9d5fc49f9f539e75cd8e",
    "url": "/js/chunk-vendors.5126acd0.js"
  },
  {
    "revision": "52381c393eaefa9d3dcdb4fbfc655fb0",
    "url": "/js/chunk-vendors.5126acd0.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);