self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2aa979c54f88edfd32c9",
    "url": "/css/app.3f9830a0.css"
  },
  {
    "revision": "5e90240e60a579786b1e",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "314b0499f59671be2127",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "097aad6a98d4e36d88a4030887a59275",
    "url": "/index.html"
  },
  {
    "revision": "2aa979c54f88edfd32c9",
    "url": "/js/app.7746b59b.js"
  },
  {
    "revision": "8828b6f4860bd18540e5",
    "url": "/js/chunk-2d0c0895.2adde7d4.js"
  },
  {
    "revision": "4db29a2aac619738b201",
    "url": "/js/chunk-2d21ef2c.9da25c92.js"
  },
  {
    "revision": "5a9553b14dbcec764261",
    "url": "/js/chunk-2d22d3f5.6623133d.js"
  },
  {
    "revision": "5e90240e60a579786b1e",
    "url": "/js/chunk-83caf4ba.2f6cc935.js"
  },
  {
    "revision": "314b0499f59671be2127",
    "url": "/js/chunk-ad949e22.59e86214.js"
  },
  {
    "revision": "10313f2ad736aacfc4d0",
    "url": "/js/chunk-vendors.7a029bc7.js"
  },
  {
    "revision": "52381c393eaefa9d3dcdb4fbfc655fb0",
    "url": "/js/chunk-vendors.7a029bc7.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);