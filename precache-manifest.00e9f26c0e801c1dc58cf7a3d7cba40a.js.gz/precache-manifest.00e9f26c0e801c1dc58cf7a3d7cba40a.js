self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "018468e9b7571fdb5832",
    "url": "/css/app.3f9830a0.css"
  },
  {
    "revision": "10bd88fe73c4224036ca",
    "url": "/css/chunk-83caf4ba.2b10a76f.css"
  },
  {
    "revision": "32a2f740da2775a3f8af",
    "url": "/css/chunk-ad949e22.7aeafeb8.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "21852fe7f5ee4ae919f63124fb3d6c63",
    "url": "/index.html"
  },
  {
    "revision": "018468e9b7571fdb5832",
    "url": "/js/app.cbd0fccf.js"
  },
  {
    "revision": "c97f6e0eb7b6e44f627b",
    "url": "/js/chunk-2d0c0895.fa2ad322.js"
  },
  {
    "revision": "a55ddd6471dc1d3ebcd3",
    "url": "/js/chunk-2d21ef2c.510e8e19.js"
  },
  {
    "revision": "71e817fc79d57cea2bce",
    "url": "/js/chunk-2d22d3f5.bc0be782.js"
  },
  {
    "revision": "10bd88fe73c4224036ca",
    "url": "/js/chunk-83caf4ba.00813b2e.js"
  },
  {
    "revision": "32a2f740da2775a3f8af",
    "url": "/js/chunk-ad949e22.ec9dfff6.js"
  },
  {
    "revision": "a3d3741827c99588d5ed",
    "url": "/js/chunk-vendors.da5a48eb.js"
  },
  {
    "revision": "d2aef1fbeed97f45c27480d4d947516b",
    "url": "/js/chunk-vendors.da5a48eb.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);