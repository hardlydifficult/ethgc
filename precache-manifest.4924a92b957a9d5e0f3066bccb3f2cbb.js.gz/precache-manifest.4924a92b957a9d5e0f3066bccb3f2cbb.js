self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "eda0edebe7f4bd770150",
    "url": "/css/app.56ff0a86.css"
  },
  {
    "revision": "78c914418b607e585142",
    "url": "/css/chunk-83caf4ba.3f95806c.css"
  },
  {
    "revision": "19d870f81f1ac395717b",
    "url": "/css/chunk-ad949e22.68276357.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "66d8bf0807efbd0c3b606e9502c89339",
    "url": "/index.html"
  },
  {
    "revision": "eda0edebe7f4bd770150",
    "url": "/js/app.9603eb4f.js"
  },
  {
    "revision": "66f2dfc86323422665f6",
    "url": "/js/chunk-2d0c0895.87d53dff.js"
  },
  {
    "revision": "b7af10844da29f207396",
    "url": "/js/chunk-2d21ef2c.3ed385f4.js"
  },
  {
    "revision": "69d79123e9e78a315a30",
    "url": "/js/chunk-2d22d3f5.398a66b4.js"
  },
  {
    "revision": "78c914418b607e585142",
    "url": "/js/chunk-83caf4ba.f3409e8a.js"
  },
  {
    "revision": "19d870f81f1ac395717b",
    "url": "/js/chunk-ad949e22.48e2289f.js"
  },
  {
    "revision": "7283447763fce4922d8c",
    "url": "/js/chunk-vendors.390e9a92.js"
  },
  {
    "revision": "07f5e22785feaadf7d3c8852f080bcb9",
    "url": "/js/chunk-vendors.390e9a92.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);