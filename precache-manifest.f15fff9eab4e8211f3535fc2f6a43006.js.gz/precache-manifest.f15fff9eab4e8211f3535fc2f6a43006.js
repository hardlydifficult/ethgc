self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b14585aff312cb3332b9",
    "url": "/css/app.56ff0a86.css"
  },
  {
    "revision": "44cd9aac0374d30c6c74",
    "url": "/css/chunk-83caf4ba.3f95806c.css"
  },
  {
    "revision": "c9c9bb5ff35a0ee30e11",
    "url": "/css/chunk-ad949e22.68276357.css"
  },
  {
    "revision": "ed43a9b178caba26ef329db6e5bbae57",
    "url": "/img/logo.ed43a9b1.png"
  },
  {
    "revision": "c14483a0f77cf9f1659be427c1e2361d",
    "url": "/index.html"
  },
  {
    "revision": "b14585aff312cb3332b9",
    "url": "/js/app.f99e27be.js"
  },
  {
    "revision": "c575e6b4b9151045d3fb",
    "url": "/js/chunk-2d0c0895.9f1ae0ac.js"
  },
  {
    "revision": "68b354a78db443545e7d",
    "url": "/js/chunk-2d21ef2c.140e5ab3.js"
  },
  {
    "revision": "d3db4731e9fdda50ecb3",
    "url": "/js/chunk-2d22d3f5.7f28462c.js"
  },
  {
    "revision": "44cd9aac0374d30c6c74",
    "url": "/js/chunk-83caf4ba.8e29a66b.js"
  },
  {
    "revision": "c9c9bb5ff35a0ee30e11",
    "url": "/js/chunk-ad949e22.00636bfc.js"
  },
  {
    "revision": "7283447763fce4922d8c",
    "url": "/js/chunk-vendors.390e9a92.js"
  },
  {
    "revision": "07f5e22785feaadf7d3c8852f080bcb9",
    "url": "/js/chunk-vendors.390e9a92.js.LICENSE.txt"
  },
  {
    "revision": "7db793db669237c9b2a4f2c8bd0db5b7",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);